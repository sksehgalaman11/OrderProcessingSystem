﻿using System;

namespace OrderProcessingSystem
{
    class Program
    {
      
        static void Main(string[] args)
        {
              
                OrderTypeConcreteCreator orderType = new OrderTypeConcreteCreator();

            string orderValue = orderType.ToString();
            Console.WriteLine("=====================       Welcome to Order Processing System     =====================");           
            Console.WriteLine("\n Please enter  your desired Order Type based on the below options \n    1.Physical Product\n    2.Book Product\n    3.MembershipProduct\n    4.VideoProduct\n");
            orderValue = Console.ReadLine();
            Console.WriteLine("Your input: {0}", orderValue);
            switch (orderValue)
            {
                case "1" :
                    orderType.ProcessOrderType("PhysicalProduct");
                    PhysicalProduct p1  = new PhysicalProduct();
                    p1.PackingSlip();
                    break;
                case "2":
                    orderType.ProcessOrderType("BookProduct");
                    BookProduct b1 = new BookProduct();
                    b1.BookDetails("LifeOfPi");
                    b1.PackingSlip();
                    break;
                case "3":
                    MembershipProduct mi = new MembershipProduct();
                    Console.WriteLine("Enter ur First Name");
                    var firstName = Console.ReadLine();
                    mi.ProcessMembership(firstName);
                    break;
                case "4":
                    orderType.ProcessOrderType("VideoProduct");
                    VideoProduct v1 = new VideoProduct();
                    v1.PackingSlip();
                    break;
                default:
                    Console.WriteLine("Order Type not mentioned");
                    break;         

            }

            Console.ReadKey();
            //orderType.ProcessOrderType("VideoProduct");
        }
    }

}
