﻿using System.Collections.Generic;

namespace OrderProcessingSystem.Models
{
    /// <summary>
    ///     Item model
    /// </summary>
    public class Item : Entity<int>
    {
        /// <summary>
        ///     Item name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        ///     Item Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        ///     Current Item Qty. Default is 0
        /// </summary>
        public int Qty { get; set; } = 0;

        /// <summary>
        ///     Navigational Property: Orders
        /// </summary>
        public virtual ICollection<Order> Orders { get; set; }
    }
}